import os
from flask import Flask, Blueprint, render_template, request, redirect, url_for, flash, jsonify, current_app
from src.routes.upload import upload_bp
from src.routes.analysis import analysis_bp
from src.utils.document_processor import DocumentProcessor
from src.utils.clause_detector import ClauseDetector
from src.utils.clause_summarizer import ClauseSummarizer

def create_app():
    """Create and configure the Flask application."""
    # Create Flask app
    app = Flask(__name__)
    app.secret_key = os.urandom(24)
    
    # Configure app
    app.config['MAX_CONTENT_LENGTH'] = 25 * 1024 * 1024  # 25MB max upload
    app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(__file__), 'static', 'uploads')
    
    # Ensure upload directory exists
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    
    # Initialize contract storage
    app.contracts = {}
    
    # Initialize analysis components
    app.clause_detector = ClauseDetector()
    app.clause_summarizer = ClauseSummarizer()
    
    # Register blueprints
    app.register_blueprint(upload_bp)
    app.register_blueprint(analysis_bp)
    
    # Register routes
    @app.route('/')
    def index():
        return redirect(url_for('upload.upload_file'))
    
    @app.route('/compare', methods=['GET'])
    def compare_contracts():
        return render_template('compare.html', contracts=app.contracts)
    
    @app.route('/export/<contract_id>', methods=['GET'])
    def export_analysis(contract_id):
        if contract_id not in app.contracts:
            flash('Contract not found')
            return redirect(url_for('upload.upload_file'))
        
        contract = app.contracts[contract_id]
        return render_template('export.html', contract=contract)
    
    return app

# This is the entry point for the Flask application
def main():
    app = create_app()
    app.run(host='0.0.0.0', port=5000, debug=True)

if __name__ == '__main__':
    main()
