import os
import fitz  # PyMuPDF
import docx
import nltk
from src.models.contract import Contract

# Download necessary NLTK data
nltk.download('punkt', quiet=True)

class DocumentProcessor:
    """Utility class for processing uploaded contract documents."""
    
    @staticmethod
    def process_document(file_path):
        """
        Extract text from uploaded document based on file type.
        
        Args:
            file_path: Path to the uploaded file
            
        Returns:
            Contract object with extracted text
        """
        filename = os.path.basename(file_path)
        file_extension = os.path.splitext(filename)[1].lower()
        
        if file_extension == '.pdf':
            return DocumentProcessor._process_pdf(file_path, filename)
        elif file_extension == '.docx':
            return DocumentProcessor._process_docx(file_path, filename)
        elif file_extension == '.txt':
            return DocumentProcessor._process_txt(file_path, filename)
        else:
            raise ValueError(f"Unsupported file type: {file_extension}")
    
    @staticmethod
    def _process_pdf(file_path, filename):
        """Extract text from PDF file."""
        text_by_page = []
        
        try:
            pdf_document = fitz.open(file_path)
            for page_num in range(len(pdf_document)):
                page = pdf_document[page_num]
                text = page.get_text()
                text_by_page.append(text)
                
            full_text = "\n\n".join(text_by_page)
            contract = Contract(filename, full_text, 'pdf')
            
            # Store page mapping information for future reference
            contract.page_mapping = {i: text for i, text in enumerate(text_by_page)}
            
            return contract
        except Exception as e:
            raise Exception(f"Error processing PDF file: {str(e)}")
    
    @staticmethod
    def _process_docx(file_path, filename):
        """Extract text from DOCX file."""
        try:
            doc = docx.Document(file_path)
            paragraphs = [p.text for p in doc.paragraphs]
            full_text = "\n".join(paragraphs)
            
            return Contract(filename, full_text, 'docx')
        except Exception as e:
            raise Exception(f"Error processing DOCX file: {str(e)}")
    
    @staticmethod
    def _process_txt(file_path, filename):
        """Extract text from TXT file."""
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                full_text = file.read()
            
            return Contract(filename, full_text, 'txt')
        except Exception as e:
            raise Exception(f"Error processing TXT file: {str(e)}")
    
    @staticmethod
    def preprocess_text(text):
        """
        Preprocess extracted text for better analysis.
        
        Args:
            text: Raw text extracted from document
            
        Returns:
            Preprocessed text
        """
        # Basic preprocessing
        # 1. Remove excessive whitespace
        text = ' '.join(text.split())
        
        # 2. Split into sentences for better analysis
        sentences = nltk.sent_tokenize(text)
        
        # 3. Normalize text (lowercase for analysis, but keep original for display)
        normalized_sentences = [sentence.lower() for sentence in sentences]
        
        return {
            'original_text': text,
            'sentences': sentences,
            'normalized_sentences': normalized_sentences
        }
