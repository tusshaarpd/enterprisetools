import nltk
import re
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import torch
import os

# Download necessary NLTK data
nltk.download('punkt', quiet=True)

class ClauseDetector:
    """Utility class for detecting and classifying legal clauses in contracts."""
    
    # Define clause types and their common keywords/patterns
    CLAUSE_TYPES = {
        'termination': [
            'termination', 'terminate', 'terminating', 'terminated', 'terminates',
            'cancellation', 'cancel', 'cancelling', 'cancelled', 'cancels',
            'end of agreement', 'end of contract'
        ],
        'indemnification': [
            'indemnification', 'indemnify', 'indemnifying', 'indemnified', 'indemnifies',
            'hold harmless', 'indemnity', 'defend and indemnify'
        ],
        'confidentiality': [
            'confidentiality', 'confidential', 'non-disclosure', 'nda',
            'proprietary information', 'trade secret', 'confidential information'
        ],
        'governing_law': [
            'governing law', 'jurisdiction', 'venue', 'applicable law',
            'law govern', 'governed by', 'laws of', 'jurisdiction of'
        ],
        'liability': [
            'liability', 'liable', 'limitation of liability', 'limited liability',
            'no liability', 'not be liable', 'damages', 'consequential damages'
        ],
        'payment_terms': [
            'payment', 'fee', 'compensation', 'invoice', 'billing',
            'pay', 'paid', 'payment terms', 'payment schedule', 'price'
        ],
        'ip_ownership': [
            'intellectual property', 'ip', 'copyright', 'patent', 'trademark',
            'ownership', 'proprietary rights', 'work product', 'invention'
        ]
    }
    
    def __init__(self, model_path=None):
        """
        Initialize the clause detector.
        
        Args:
            model_path: Path to pre-trained model (if None, uses rule-based detection)
        """
        self.use_ml = model_path is not None
        
        if self.use_ml:
            # Load pre-trained model for clause classification
            self.tokenizer = AutoTokenizer.from_pretrained(model_path)
            self.model = AutoModelForSequenceClassification.from_pretrained(model_path)
        
        # Compile regex patterns for rule-based detection
        self.clause_patterns = {}
        for clause_type, keywords in self.CLAUSE_TYPES.items():
            pattern = r'(?i)(' + '|'.join(keywords) + r')'
            self.clause_patterns[clause_type] = re.compile(pattern)
    
    def detect_clauses(self, contract):
        """
        Detect and classify clauses in the contract.
        
        Args:
            contract: Contract object with extracted text
            
        Returns:
            Updated contract with detected clauses
        """
        # Split text into paragraphs (potential clauses)
        paragraphs = self._split_into_paragraphs(contract.original_text)
        
        # Process each paragraph
        for i, paragraph in enumerate(paragraphs):
            # Skip very short paragraphs (likely not clauses)
            if len(paragraph.strip()) < 20:
                continue
            
            # Detect clause type
            clause_type, confidence = self._classify_clause(paragraph)
            
            if clause_type:
                # Add clause to contract
                page_num = self._estimate_page_number(contract, paragraph)
                clause_index = contract.add_clause(
                    clause_type=clause_type,
                    text=paragraph,
                    page_num=page_num
                )
                
                # Perform initial risk assessment
                risk_level, risk_description = self._assess_risk(clause_type, paragraph)
                if risk_level:
                    contract.clauses[clause_index]['risk_level'] = risk_level
                    contract.add_risk(risk_description, risk_level, clause_index)
        
        return contract
    
    def _split_into_paragraphs(self, text):
        """Split text into paragraphs based on line breaks."""
        # Split by double line breaks first (preferred paragraph separator)
        paragraphs = re.split(r'\n\s*\n', text)
        
        # Further split long paragraphs that might contain multiple clauses
        result = []
        for para in paragraphs:
            # If paragraph is very long, try to split by section numbers or headers
            if len(para) > 1000:
                # Look for section numbering patterns
                sub_paras = re.split(r'\n\s*\d+\.[\d\.]*\s+', para)
                if len(sub_paras) > 1:
                    result.extend(sub_paras)
                else:
                    result.append(para)
            else:
                result.append(para)
        
        return result
    
    def _classify_clause(self, text):
        """
        Classify the type of clause.
        
        Args:
            text: Clause text
            
        Returns:
            Tuple of (clause_type, confidence)
        """
        if self.use_ml:
            return self._classify_with_model(text)
        else:
            return self._classify_with_rules(text)
    
    def _classify_with_rules(self, text):
        """Use rule-based approach to classify clause."""
        best_match = None
        max_matches = 0
        
        for clause_type, pattern in self.clause_patterns.items():
            matches = len(pattern.findall(text))
            if matches > max_matches:
                max_matches = matches
                best_match = clause_type
        
        # Require at least one match
        if max_matches > 0:
            confidence = min(max_matches / 3, 1.0)  # Normalize confidence
            return best_match, confidence
        
        return None, 0.0
    
    def _classify_with_model(self, text):
        """Use ML model to classify clause."""
        # Truncate text if too long for model
        max_length = self.tokenizer.model_max_length
        inputs = self.tokenizer(text, truncation=True, max_length=max_length, return_tensors="pt")
        
        with torch.no_grad():
            outputs = self.model(**inputs)
            predictions = outputs.logits.softmax(dim=-1)
            
        # Get predicted class and confidence
        predicted_class_id = predictions.argmax().item()
        confidence = predictions[0, predicted_class_id].item()
        
        # Map class ID to clause type
        clause_types = list(self.CLAUSE_TYPES.keys())
        if predicted_class_id < len(clause_types):
            return clause_types[predicted_class_id], confidence
        
        return None, 0.0
    
    def _estimate_page_number(self, contract, paragraph):
        """Estimate the page number for a paragraph."""
        if hasattr(contract, 'page_mapping'):
            # Try to find which page contains this paragraph
            for page_num, page_text in contract.page_mapping.items():
                if paragraph in page_text:
                    return page_num
        
        # Default to page 1 if we can't determine
        return 1
    
    def _assess_risk(self, clause_type, text):
        """
        Perform initial risk assessment on clause.
        
        Args:
            clause_type: Type of clause
            text: Clause text
            
        Returns:
            Tuple of (risk_level, risk_description)
        """
        text_lower = text.lower()
        
        # Check for common risk patterns based on clause type
        if clause_type == 'liability':
            if 'unlimited' in text_lower or 'uncapped' in text_lower:
                return 'high', 'Unlimited liability clause detected'
            if 'limited to' in text_lower and ('fees paid' in text_lower or 'amount paid' in text_lower):
                return 'low', 'Liability limited to fees paid'
                
        elif clause_type == 'termination':
            if 'automatic' in text_lower and 'renewal' in text_lower:
                return 'medium', 'Automatic renewal clause detected'
            if 'without cause' in text_lower or 'without reason' in text_lower:
                return 'medium', 'Termination without cause clause detected'
                
        elif clause_type == 'indemnification':
            if 'defend' in text_lower and 'indemnify' in text_lower and 'hold harmless' in text_lower:
                return 'medium', 'Broad indemnification clause detected'
            if ('your' in text_lower or 'client' in text_lower) and not ('our' in text_lower or 'provider' in text_lower):
                return 'high', 'One-sided indemnification clause detected'
                
        elif clause_type == 'governing_law':
            # This would need to be customized based on client's jurisdiction
            if 'arbitration' in text_lower:
                return 'low', 'Arbitration clause detected'
                
        # Default: no risk detected
        return None, None
