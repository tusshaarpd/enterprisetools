import os
import nltk

# Download necessary NLTK data
nltk.download('punkt', quiet=True)

# Create sample test data directory
os.makedirs('test_data', exist_ok=True)
