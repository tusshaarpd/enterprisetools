import nltk
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
import torch
import re

# Download necessary NLTK data
nltk.download('punkt', quiet=True)

class ClauseSummarizer:
    """Utility class for summarizing legal clauses and identifying risks."""
    
    def __init__(self, model_path=None):
        """
        Initialize the clause summarizer.
        
        Args:
            model_path: Path to pre-trained model (if None, uses rule-based summarization)
        """
        self.use_ml = model_path is not None
        
        if self.use_ml:
            # Load pre-trained model for summarization
            self.tokenizer = AutoTokenizer.from_pretrained(model_path)
            self.model = AutoModelForSeq2SeqLM.from_pretrained(model_path)
        
        # Standard clause templates for comparison
        self.standard_templates = {
            'termination': {
                'text': "Either party may terminate this Agreement with 30 days' written notice. Upon termination, all rights and obligations of the parties shall cease, except for obligations that expressly survive termination.",
                'key_elements': ['notice period', 'written notice', 'surviving obligations']
            },
            'indemnification': {
                'text': "Each party shall indemnify, defend and hold harmless the other party from and against any and all claims, damages, liabilities, costs and expenses arising from the indemnifying party's breach of this Agreement.",
                'key_elements': ['mutual indemnification', 'breach of agreement', 'claims and damages']
            },
            'confidentiality': {
                'text': "Each party shall maintain the confidentiality of all Confidential Information disclosed by the other party and shall not use such Confidential Information for any purpose other than as expressly permitted under this Agreement.",
                'key_elements': ['mutual obligation', 'use restriction', 'confidential information definition']
            },
            'governing_law': {
                'text': "This Agreement shall be governed by and construed in accordance with the laws of [Jurisdiction], without giving effect to any choice of law or conflict of law provisions.",
                'key_elements': ['governing jurisdiction', 'conflict of laws']
            },
            'liability': {
                'text': "Neither party shall be liable for any indirect, incidental, special, consequential or punitive damages. Each party's total liability shall not exceed the fees paid under this Agreement in the 12 months preceding the claim.",
                'key_elements': ['limitation of liability', 'liability cap', 'excluded damages']
            },
            'payment_terms': {
                'text': "Client shall pay all invoices within 30 days of receipt. Late payments shall accrue interest at the rate of 1.5% per month or the maximum rate permitted by law, whichever is less.",
                'key_elements': ['payment period', 'late payment consequences', 'interest rate']
            },
            'ip_ownership': {
                'text': "Each party shall retain ownership of its pre-existing intellectual property. All intellectual property created by Provider in performing the services shall be owned by Client upon full payment.",
                'key_elements': ['pre-existing IP', 'new IP ownership', 'payment condition']
            }
        }
    
    def summarize_clauses(self, contract):
        """
        Summarize clauses and identify risks in the contract.
        
        Args:
            contract: Contract object with detected clauses
            
        Returns:
            Updated contract with clause summaries and identified risks
        """
        for i, clause in enumerate(contract.clauses):
            # Generate summary
            summary = self._generate_summary(clause['type'], clause['text'])
            contract.clauses[i]['summary'] = summary
            
            # Identify deviations from standard language
            deviations = self._identify_deviations(clause['type'], clause['text'])
            for deviation in deviations:
                contract.add_deviation(i, deviation['standard'], deviation['description'])
                
                # Add risk if deviation is significant
                if deviation['risk_level']:
                    contract.add_risk(
                        description=f"Deviation in {clause['type']} clause: {deviation['description']}",
                        severity=deviation['risk_level'],
                        clause_index=i
                    )
        
        # Generate overall contract summary
        contract.summary = self._generate_contract_summary(contract)
        
        return contract
    
    def _generate_summary(self, clause_type, text):
        """
        Generate a summary for a clause.
        
        Args:
            clause_type: Type of clause
            text: Clause text
            
        Returns:
            Summary text
        """
        if self.use_ml:
            return self._summarize_with_model(clause_type, text)
        else:
            return self._summarize_with_rules(clause_type, text)
    
    def _summarize_with_rules(self, clause_type, text):
        """Use rule-based approach to summarize clause."""
        # Extract key information based on clause type
        if clause_type == 'termination':
            # Look for notice period
            notice_match = re.search(r'(\d+)\s*(day|days|month|months|year|years)', text, re.IGNORECASE)
            notice_period = notice_match.group(0) if notice_match else "unspecified period"
            
            # Look for termination conditions
            conditions = []
            if re.search(r'without\s*cause', text, re.IGNORECASE):
                conditions.append("without cause")
            if re.search(r'with\s*cause', text, re.IGNORECASE) or re.search(r'for\s*cause', text, re.IGNORECASE):
                conditions.append("for cause")
            if re.search(r'breach', text, re.IGNORECASE):
                conditions.append("upon breach")
            
            conditions_text = ", ".join(conditions) if conditions else "under specified conditions"
            
            return f"Termination allowed with {notice_period} notice {conditions_text}."
            
        elif clause_type == 'indemnification':
            # Determine if indemnification is mutual or one-sided
            if (re.search(r'each\s*party', text, re.IGNORECASE) or 
                (re.search(r'client', text, re.IGNORECASE) and re.search(r'provider', text, re.IGNORECASE))):
                party = "Each party"
            elif re.search(r'client', text, re.IGNORECASE) or re.search(r'customer', text, re.IGNORECASE):
                party = "Client"
            elif re.search(r'provider', text, re.IGNORECASE) or re.search(r'vendor', text, re.IGNORECASE):
                party = "Provider"
            else:
                party = "One party"
            
            return f"{party} must indemnify against claims arising from breach of agreement or negligence."
            
        elif clause_type == 'confidentiality':
            # Determine duration
            duration_match = re.search(r'(\d+)\s*(day|days|month|months|year|years)', text, re.IGNORECASE)
            duration = duration_match.group(0) if duration_match else "unspecified period"
            
            if re.search(r'perpetual', text, re.IGNORECASE) or re.search(r'indefinite', text, re.IGNORECASE):
                duration = "perpetual duration"
            
            return f"Confidential information must be protected for {duration} and not used outside agreement scope."
            
        elif clause_type == 'governing_law':
            # Extract jurisdiction
            jurisdiction_match = re.search(r'laws\s*of\s*([A-Za-z\s]+)', text)
            jurisdiction = jurisdiction_match.group(1).strip() if jurisdiction_match else "specified jurisdiction"
            
            # Check for arbitration
            if re.search(r'arbitration', text, re.IGNORECASE):
                return f"Governed by laws of {jurisdiction} with disputes resolved through arbitration."
            else:
                return f"Governed by laws of {jurisdiction}."
            
        elif clause_type == 'liability':
            # Check for liability cap
            cap_match = re.search(r'limited\s*to\s*([^\.]+)', text, re.IGNORECASE)
            cap = cap_match.group(1).strip() if cap_match else "unspecified amount"
            
            if re.search(r'no\s*liability', text, re.IGNORECASE) or re.search(r'not\s*be\s*liable', text, re.IGNORECASE):
                return "No liability for certain damages or claims."
            elif re.search(r'unlimited', text, re.IGNORECASE) or re.search(r'uncapped', text, re.IGNORECASE):
                return "Unlimited liability for damages or claims."
            else:
                return f"Liability limited to {cap}."
            
        elif clause_type == 'payment_terms':
            # Look for payment period
            period_match = re.search(r'(\d+)\s*(day|days|month|months)', text, re.IGNORECASE)
            period = period_match.group(0) if period_match else "unspecified period"
            
            # Look for late payment terms
            if re.search(r'interest', text, re.IGNORECASE):
                interest_match = re.search(r'(\d+(\.\d+)?)\s*%', text)
                interest = interest_match.group(0) if interest_match else "an unspecified rate"
                return f"Payment due within {period} with interest at {interest} for late payments."
            else:
                return f"Payment due within {period}."
            
        elif clause_type == 'ip_ownership':
            if re.search(r'client\s*own', text, re.IGNORECASE) or re.search(r'owned\s*by\s*client', text, re.IGNORECASE):
                return "Client owns all intellectual property created under the agreement."
            elif re.search(r'provider\s*own', text, re.IGNORECASE) or re.search(r'owned\s*by\s*provider', text, re.IGNORECASE):
                return "Provider retains ownership of intellectual property created under the agreement."
            elif re.search(r'each\s*party', text, re.IGNORECASE) or re.search(r'retain', text, re.IGNORECASE):
                return "Each party retains its own intellectual property with limited license to the other party."
            else:
                return "Specifies intellectual property ownership and usage rights."
        
        # Default summary for unrecognized clause types
        return "This clause contains legal provisions related to " + clause_type.replace('_', ' ') + "."
    
    def _summarize_with_model(self, clause_type, text):
        """Use ML model to summarize clause."""
        # Prepare prompt for the model
        prompt = f"Summarize this {clause_type.replace('_', ' ')} clause in one or two sentences: {text}"
        
        # Truncate text if too long for model
        max_length = self.tokenizer.model_max_length
        inputs = self.tokenizer(prompt, truncation=True, max_length=max_length, return_tensors="pt")
        
        # Generate summary
        with torch.no_grad():
            outputs = self.model.generate(
                inputs["input_ids"],
                max_length=100,
                num_beams=4,
                early_stopping=True
            )
            
        summary = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        return summary
    
    def _identify_deviations(self, clause_type, text):
        """
        Identify deviations from standard clause language.
        
        Args:
            clause_type: Type of clause
            text: Clause text
            
        Returns:
            List of deviations with standard text and description
        """
        deviations = []
        
        # Skip if no standard template exists for this clause type
        if clause_type not in self.standard_templates:
            return deviations
        
        standard = self.standard_templates[clause_type]
        text_lower = text.lower()
        
        # Check for key elements based on clause type
        if clause_type == 'termination':
            # Check for notice period
            if not re.search(r'\d+\s*(day|days|month|months)', text_lower):
                deviations.append({
                    'standard': "Termination with specified notice period",
                    'description': "No specific notice period for termination",
                    'risk_level': 'medium'
                })
            
            # Check for immediate termination
            if re.search(r'immediately|without\s*notice', text_lower):
                deviations.append({
                    'standard': "Termination with reasonable notice",
                    'description': "Allows immediate termination without notice",
                    'risk_level': 'high'
                })
                
        elif clause_type == 'indemnification':
            # Check if indemnification is one-sided
            if ((re.search(r'client', text_lower) or re.search(r'customer', text_lower)) and 
                not (re.search(r'provider', text_lower) or re.search(r'vendor', text_lower)) and
                not re.search(r'each\s*party', text_lower)):
                deviations.append({
                    'standard': "Mutual indemnification obligations",
                    'description': "One-sided indemnification favoring provider",
                    'risk_level': 'high'
                })
            
            # Check for uncapped indemnification
            if not re.search(r'limit|cap|maximum', text_lower):
                deviations.append({
                    'standard': "Indemnification with reasonable limits",
                    'description': "Uncapped indemnification obligation",
                    'risk_level': 'medium'
                })
                
        elif clause_type == 'liability':
            # Check for unlimited liability
            if re.search(r'unlimited|uncapped', text_lower):
                deviations.append({
                    'standard': "Liability limited to fees paid",
                    'description': "Unlimited liability exposure",
                    'risk_level': 'high'
                })
            
            # Check for missing exclusion of consequential damages
            if not re.search(r'consequential|indirect|special|incidental', text_lower):
                deviations.append({
                    'standard': "Exclusion of consequential and indirect damages",
                    'description': "No exclusion of consequential damages",
                    'risk_level': 'medium'
                })
                
        elif clause_type == 'payment_terms':
            # Check for short payment terms
            short_payment = re.search(r'(\d+)\s*(day|days)', text_lower)
            if short_payment and int(short_payment.group(1)) < 15:
                deviations.append({
                    'standard': "Payment terms of 30 days",
                    'description': f"Short payment term of {short_payment.group(0)}",
                    'risk_level': 'medium'
                })
            
            # Check for high interest rates
            interest_match = re.search(r'(\d+(\.\d+)?)\s*%', text_lower)
            if interest_match and float(interest_match.group(1)) > 2:
                deviations.append({
                    'standard': "Reasonable interest rate for late payments",
                    'description': f"High interest rate of {interest_match.group(0)} for late payments",
                    'risk_level': 'low'
                })
                
        elif clause_type == 'ip_ownership':
            # Check for unfavorable IP ownership
            if re.search(r'(provider|vendor|contractor)\s*(own|retain)', text_lower) and not re.search(r'(client|customer)\s*(own|retain)', text_lower):
                deviations.append({
                    'standard': "Client ownership of work product",
                    'description': "Provider retains ownership of work product",
                    'risk_level': 'high'
                })
        
        return deviations
    
    def _generate_contract_summary(self, contract):
        """
        Generate an overall summary of the contract.
        
        Args:
            contract: Contract object with clauses and risks
            
        Returns:
            Summary text
        """
        # Count clauses by type
        clause_counts = {}
        for clause in contract.clauses:
            clause_type = clause['type']
            clause_counts[clause_type] = clause_counts.get(clause_type, 0) + 1
        
        # Count risks by severity
        risk_counts = {'high': 0, 'medium': 0, 'low': 0}
        for risk in contract.risks:
            risk_counts[risk['severity']] = risk_counts.get(risk['severity'], 0) + 1
        
        # Generate summary text
        summary = f"This contract contains {len(contract.clauses)} clauses, including "
        
        # List clause types
        clause_types = [f"{count} {clause_type.replace('_', ' ')}" for clause_type, count in clause_counts.items()]
        summary += ", ".join(clause_types) + ". "
        
        # Add risk summary
        total_risks = sum(risk_counts.values())
        if total_risks > 0:
            summary += f"Analysis identified {total_risks} potential risks: "
            summary += f"{risk_counts['high']} high, {risk_counts['medium']} medium, and {risk_counts['low']} low severity issues."
        else:
            summary += "No significant risks were identified in the analysis."
        
        return summary
