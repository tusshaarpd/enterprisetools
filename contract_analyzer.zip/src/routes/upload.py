import os
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, current_app
from werkzeug.utils import secure_filename
from src.utils.document_processor import DocumentProcessor

# Create a blueprint for upload routes
upload_bp = Blueprint('upload', __name__)

# Configure upload settings
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', 'uploads')
ALLOWED_EXTENSIONS = {'pdf', 'docx', 'txt'}
MAX_CONTENT_LENGTH = 25 * 1024 * 1024  # 25MB

# Ensure upload directory exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    """Check if the file has an allowed extension."""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@upload_bp.route('/upload', methods=['GET', 'POST'])
def upload_file():
    """Handle file upload."""
    if request.method == 'POST':
        # Check if the post request has the file part
        if 'contract_file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        
        file = request.files['contract_file']
        
        # If user does not select file, browser also submits an empty part without filename
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_path = os.path.join(UPLOAD_FOLDER, filename)
            
            # Save the uploaded file
            file.save(file_path)
            
            try:
                # Process the document
                contract = DocumentProcessor.process_document(file_path)
                
                # Store the contract in session for now (will be replaced with database in future)
                # For simplicity, we'll just store the contract ID in session and keep contracts in memory
                if not hasattr(current_app, 'contracts'):
                    current_app.contracts = {}
                
                contract_id = str(len(current_app.contracts) + 1)
                contract.id = contract_id
                current_app.contracts[contract_id] = contract
                
                # Redirect to the analysis page
                return redirect(url_for('analysis.analyze_contract', contract_id=contract_id))
            
            except Exception as e:
                flash(f'Error processing file: {str(e)}')
                # Clean up the uploaded file if processing failed
                if os.path.exists(file_path):
                    os.remove(file_path)
                return redirect(request.url)
        else:
            flash(f'Invalid file type. Allowed types: {", ".join(ALLOWED_EXTENSIONS)}')
            return redirect(request.url)
    
    # GET request - show upload form
    return render_template('upload.html')

@upload_bp.route('/api/upload', methods=['POST'])
def api_upload():
    """API endpoint for file upload."""
    # Check if the post request has the file part
    if 'contract_file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['contract_file']
    
    # If user does not select file, browser also submits an empty part without filename
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file_path = os.path.join(UPLOAD_FOLDER, filename)
        
        # Save the uploaded file
        file.save(file_path)
        
        try:
            # Process the document
            contract = DocumentProcessor.process_document(file_path)
            
            # Store the contract in session for now (will be replaced with database in future)
            if not hasattr(current_app, 'contracts'):
                current_app.contracts = {}
            
            contract_id = str(len(current_app.contracts) + 1)
            contract.id = contract_id
            current_app.contracts[contract_id] = contract
            
            # Return success response
            return jsonify({
                'success': True,
                'contract_id': contract_id,
                'filename': filename,
                'file_type': contract.file_type,
                'text_length': len(contract.original_text)
            })
        
        except Exception as e:
            # Clean up the uploaded file if processing failed
            if os.path.exists(file_path):
                os.remove(file_path)
            return jsonify({'error': str(e)}), 500
    else:
        return jsonify({'error': f'Invalid file type. Allowed types: {", ".join(ALLOWED_EXTENSIONS)}'}), 400
