import os
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, current_app, send_file
from werkzeug.utils import secure_filename
import json
import tempfile
import shutil
from datetime import datetime

# Create a blueprint for analysis routes
analysis_bp = Blueprint('analysis', __name__)

@analysis_bp.route('/analyze/<contract_id>', methods=['GET'])
def analyze_contract(contract_id):
    """Display contract analysis page."""
    # Get the contract from app context
    if not hasattr(current_app, 'contracts') or contract_id not in current_app.contracts:
        flash('Contract not found')
        return redirect(url_for('upload.upload_file'))
    
    contract = current_app.contracts[contract_id]
    
    # If contract hasn't been analyzed yet, perform analysis
    if not contract.clauses:
        try:
            # Detect clauses
            contract = current_app.clause_detector.detect_clauses(contract)
            
            # Summarize clauses and identify risks
            contract = current_app.clause_summarizer.summarize_clauses(contract)
            
            # Update contract in app context
            current_app.contracts[contract_id] = contract
        except Exception as e:
            flash(f'Error analyzing contract: {str(e)}')
    
    return render_template('analysis.html', contract=contract)

@analysis_bp.route('/api/analyze/<contract_id>', methods=['GET'])
def api_analyze_contract(contract_id):
    """API endpoint for contract analysis."""
    # Get the contract from app context
    if not hasattr(current_app, 'contracts') or contract_id not in current_app.contracts:
        return jsonify({'error': 'Contract not found'}), 404
    
    contract = current_app.contracts[contract_id]
    
    # If contract hasn't been analyzed yet, perform analysis
    if not contract.clauses:
        try:
            # Detect clauses
            contract = current_app.clause_detector.detect_clauses(contract)
            
            # Summarize clauses and identify risks
            contract = current_app.clause_summarizer.summarize_clauses(contract)
            
            # Update contract in app context
            current_app.contracts[contract_id] = contract
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    
    # Return contract data
    return jsonify(contract.to_dict())

@analysis_bp.route('/api/clauses/<contract_id>', methods=['GET'])
def api_get_clauses(contract_id):
    """API endpoint for getting clauses."""
    # Get the contract from app context
    if not hasattr(current_app, 'contracts') or contract_id not in current_app.contracts:
        return jsonify({'error': 'Contract not found'}), 404
    
    contract = current_app.contracts[contract_id]
    
    # Filter clauses based on query parameters
    clause_type = request.args.get('type', 'all')
    risk_level = request.args.get('risk', 'all')
    
    filtered_clauses = contract.clauses
    
    if clause_type != 'all':
        filtered_clauses = [c for c in filtered_clauses if c['type'] == clause_type]
    
    if risk_level != 'all':
        filtered_clauses = [c for c in filtered_clauses if c.get('risk_level') == risk_level]
    
    return jsonify(filtered_clauses)

@analysis_bp.route('/api/risks/<contract_id>', methods=['GET'])
def api_get_risks(contract_id):
    """API endpoint for getting risks."""
    # Get the contract from app context
    if not hasattr(current_app, 'contracts') or contract_id not in current_app.contracts:
        return jsonify({'error': 'Contract not found'}), 404
    
    contract = current_app.contracts[contract_id]
    
    # Filter risks based on query parameters
    severity = request.args.get('severity', 'all')
    
    filtered_risks = contract.risks
    
    if severity != 'all':
        filtered_risks = [r for r in filtered_risks if r['severity'] == severity]
    
    return jsonify(filtered_risks)

@analysis_bp.route('/export/<contract_id>', methods=['GET'])
def export_analysis(contract_id):
    """Export contract analysis as PDF."""
    # Get the contract from app context
    if not hasattr(current_app, 'contracts') or contract_id not in current_app.contracts:
        flash('Contract not found')
        return redirect(url_for('upload.upload_file'))
    
    contract = current_app.contracts[contract_id]
    
    # Create a temporary HTML file with the analysis
    with tempfile.NamedTemporaryFile(suffix='.html', delete=False) as temp_html:
        html_content = render_template('export.html', contract=contract)
        temp_html.write(html_content.encode('utf-8'))
        temp_html_path = temp_html.name
    
    # Create a temporary PDF file
    temp_pdf_fd, temp_pdf_path = tempfile.mkstemp(suffix='.pdf')
    os.close(temp_pdf_fd)
    
    try:
        # Convert HTML to PDF using weasyprint
        from weasyprint import HTML
        HTML(temp_html_path).write_pdf(temp_pdf_path)
        
        # Send the PDF file
        return send_file(
            temp_pdf_path,
            as_attachment=True,
            download_name=f"contract_analysis_{contract.id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf",
            mimetype='application/pdf'
        )
    except Exception as e:
        flash(f'Error exporting analysis: {str(e)}')
        return redirect(url_for('analysis.analyze_contract', contract_id=contract_id))
    finally:
        # Clean up temporary files
        if os.path.exists(temp_html_path):
            os.unlink(temp_html_path)
        # The temp_pdf_path will be removed automatically by Flask after sending
