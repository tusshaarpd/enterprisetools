from datetime import datetime

class Contract:
    """Model for storing contract information and analysis results."""
    
    def __init__(self, filename, original_text, file_type):
        self.id = None  # Will be set when saved to database
        self.filename = filename
        self.original_text = original_text
        self.file_type = file_type
        self.upload_date = datetime.now()
        self.clauses = []  # List of extracted clauses
        self.summary = None  # Overall contract summary
        self.risks = []  # List of identified risks
        
    def add_clause(self, clause_type, text, page_num, summary=None, risk_level=None):
        """Add a clause to the contract."""
        clause = {
            'type': clause_type,
            'text': text,
            'page_num': page_num,
            'summary': summary,
            'risk_level': risk_level,  # None, 'low', 'medium', 'high'
            'deviations': []  # List of deviations from standard language
        }
        self.clauses.append(clause)
        return len(self.clauses) - 1  # Return index of added clause
    
    def add_risk(self, description, severity, clause_index=None):
        """Add a risk to the contract."""
        risk = {
            'description': description,
            'severity': severity,  # 'low', 'medium', 'high'
            'clause_index': clause_index  # Index of related clause, if any
        }
        self.risks.append(risk)
        
    def add_deviation(self, clause_index, standard_text, deviation_description):
        """Add a deviation from standard language to a clause."""
        if 0 <= clause_index < len(self.clauses):
            deviation = {
                'standard_text': standard_text,
                'description': deviation_description
            }
            self.clauses[clause_index]['deviations'].append(deviation)
    
    def to_dict(self):
        """Convert contract to dictionary for JSON serialization."""
        return {
            'id': self.id,
            'filename': self.filename,
            'file_type': self.file_type,
            'upload_date': self.upload_date.isoformat(),
            'summary': self.summary,
            'clauses': self.clauses,
            'risks': self.risks
        }
