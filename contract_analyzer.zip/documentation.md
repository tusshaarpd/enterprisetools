# Contract Analyzer - User Documentation

## Overview

The Contract Analyzer is a web-based application that helps legal, procurement, and business teams analyze contracts by:

- Extracting and structuring key clauses
- Identifying potential risks and red flags
- Classifying clauses by type (e.g., Termination, Indemnity)
- Detecting deviations from standard language
- Comparing multiple contracts

## Features

### 1. Document Upload
- Supports PDF, DOCX, and TXT formats
- Maximum file size: 25MB
- Drag-and-drop interface

### 2. Clause Detection & Classification
The system automatically identifies and classifies clauses into the following types:
- Termination
- Indemnification
- Confidentiality
- Governing Law
- Liability
- Payment Terms
- IP Ownership

### 3. Risk Identification
The system highlights potential risks in contracts, including:
- Uncapped liability
- Automatic renewal clauses
- Jurisdiction mismatches
- One-sided indemnity clauses

### 4. Interactive Dashboard
- Contract overview with summary statistics
- Clause browser with filtering options
- Risk highlighting and categorization

### 5. Export Functionality
- Export annotated contract analysis as PDF
- Includes clause summaries, risk assessments, and original text

### 6. Contract Comparison
- Compare two contracts side-by-side
- Identify differences in clause types and risk profiles

## Installation & Setup

### Prerequisites
- Python 3.11 or higher
- Flask and related dependencies
- Document processing libraries (PyMuPDF, python-docx)
- NLP libraries (NLTK, Transformers)

### Installation Steps
1. Clone the repository
2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
3. Run the application:
   ```
   python -m src.main
   ```

## Usage Guide

### Uploading a Contract
1. Navigate to the home page
2. Drag and drop your contract file or click "Browse Files"
3. Click "Upload & Analyze"

### Viewing Analysis Results
After uploading, you'll be redirected to the analysis page with three tabs:
- **Clauses**: View all detected clauses with summaries
- **Risks & Red Flags**: View identified risks sorted by severity
- **Original Text**: View the full contract text

### Filtering Clauses
Use the filters on the left side of the Clauses tab to:
- Filter by clause type (e.g., show only Termination clauses)
- Filter by risk level (high, medium, low, or none)

### Exporting Analysis
Click the "Export Analysis" button to generate a PDF report containing:
- Contract summary
- Risk assessment
- Detailed clause analysis

### Comparing Contracts
1. Navigate to the Compare page
2. Select two contracts from the dropdown menus
3. Click "Compare" to see a side-by-side comparison

## Technical Architecture

The application is built using:
- **Backend**: Flask (Python)
- **Frontend**: HTML, CSS, JavaScript with Bootstrap
- **Document Processing**: PyMuPDF, python-docx
- **NLP**: NLTK, Transformers

### Project Structure
```
contract_analyzer/
├── src/
│   ├── models/       # Data models
│   ├── routes/       # API endpoints
│   ├── static/       # Static assets
│   ├── templates/    # HTML templates
│   ├── utils/        # Utility functions
│   └── main.py       # Application entry point
├── venv/             # Virtual environment
└── requirements.txt  # Dependencies
```

## Limitations & Future Improvements

### Current Limitations
- Rule-based clause detection has limited accuracy
- No user authentication or multi-user support
- Limited support for complex document formats

### Planned Improvements
- ML-based clause detection for improved accuracy
- User authentication and role-based access
- Database integration for persistent storage
- API access for programmatic integration
- Support for additional document formats

## Troubleshooting

### Common Issues
- **File upload errors**: Ensure file is under 25MB and in a supported format
- **Missing clauses**: Some clauses may not be detected if they use non-standard language
- **Export errors**: Ensure weasyprint is properly installed

### Support
For additional support, please contact the development team.
